DTAG bundle: one folder per respondent (see each folder's README.txt and report.md),
comparison.csv / comparison.svg align their ideology trajectories by question number,
bundle_manifest.json lists the respondents.
